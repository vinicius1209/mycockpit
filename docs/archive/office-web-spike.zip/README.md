# MyCockpit Agent Office

Spike M0 de um escritório virtual isométrico para visualizar agentes do MyCockpit.
Os três estados exibidos nesta fase (`idle`, `typing` e `thinking`) são fixtures locais;
nenhum socket ou integração com o runtime Tauri foi adicionado.

```bash
bun install
bun run dev
```

Validação:

```bash
bun run build
bun run test
```

O app Vite usa `127.0.0.1:5174` em desenvolvimento. O transporte de eventos ao vivo
está deliberadamente fora deste marco.
