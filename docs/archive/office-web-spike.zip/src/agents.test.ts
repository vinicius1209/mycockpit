import { describe, expect, it } from 'vitest'
import { agents } from './agents'

describe('office agent fixture', () => {
  it('covers the three visual states used by the M0 spike', () => {
    expect(new Set(agents.map((agent) => agent.state))).toEqual(
      new Set(['idle', 'typing', 'thinking']),
    )
  })

  it('keeps stable unique agent identities for future events', () => {
    const ids = agents.map((agent) => agent.id)
    expect(new Set(ids).size).toBe(ids.length)
  })
})
