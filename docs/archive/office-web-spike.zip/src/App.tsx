import { agents, stateColors, type Agent } from './agents'

const stateCopy = {
  thinking: 'Pensando',
  typing: 'Escrevendo',
  idle: 'Disponível',
} as const

function Desk({ x, y, flip = false }: { x: number; y: number; flip?: boolean }) {
  return (
    <g transform={`translate(${x} ${y})${flip ? ' scale(-1 1)' : ''}`} className="desk">
      <path d="M-76 0 0-38 76 0 0 39Z" fill="#d7d0b8" />
      <path d="M-76 0 0 39v18l-76-38Z" fill="#69746c" />
      <path d="M76 0 0 39v18l76-38Z" fill="#4d5954" />
      <path d="M-51 27v50l13 7V34ZM51 27v50l-13 7V34Z" fill="#3a4541" />
      <g className="monitor">
        <path d="m-28-30 43-21 32 16-43 22Z" fill="#1c2225" />
        <path d="m-28-30 32 17v32l-32-17Z" fill="#303a3c" />
        <path d="m-22-25 21 11V9L-22-2Z" fill="#73aaa4" />
        <path d="M4 19v12l13-6V13Z" fill="#22292b" />
      </g>
      <path d="m27-9 24-12 13 7-24 12Z" fill="#f2ead2" />
      <path d="m-3 7 29-14 12 6L9 13Z" fill="#b9c1b2" opacity=".8" />
    </g>
  )
}

function AgentPiece({ agent, x, y }: { agent: Agent; x: number; y: number }) {
  const skin = agent.id === 'codex' ? '#794b37' : agent.id === 'claude' ? '#d7a77e' : '#a86f4e'

  return (
    <g transform={`translate(${x} ${y})`} className={`agent-piece agent-${agent.state}`}>
      <g className="agent-label" transform="translate(-88 -145)">
        <rect width="176" height="60" rx="12" fill="#0b1018" stroke={agent.color} strokeWidth="2" />
        <path d="m80 60 8 11 8-11Z" fill={agent.color} />
        <circle cx="151" cy="30" r="6" fill={agent.color} />
        <text x="16" y="26" className="label-name">{agent.name}</text>
        <text x="16" y="44" className="label-state">{agent.stateLabel}</text>
      </g>

      <ellipse cx="0" cy="17" rx="35" ry="17" fill="#11161c" opacity=".28" />
      <path d="M-24-35 0-47l24 12V5L0 18-24 5Z" fill={agent.color} />
      <path d="M0-47 24-35V5L0 18Z" fill="#000" opacity=".16" />
      <ellipse cx="0" cy="-53" rx="21" ry="18" fill={skin} />
      <path d="M-20-57c5-23 34-24 41 0-8-4-14-8-22-8-7 0-13 4-19 8Z" fill="#20262b" />
      <g className="arm arm-left">
        <path d="m-23-31-17 20 9 7 19-18Z" fill={skin} />
      </g>
      <g className="arm arm-right">
        <path d="m23-31 17 20-9 7-19-18Z" fill={skin} />
      </g>

      {agent.state === 'thinking' && (
        <g className="thought-dots" transform="translate(34 -83)">
          <circle r="4" fill={agent.color} />
          <circle cx="13" cy="-9" r="6" fill={agent.color} />
          <circle cx="31" cy="-17" r="9" fill={agent.color} />
        </g>
      )}
      {agent.state === 'idle' && (
        <g transform="translate(38 -17)">
          <path d="M-9-5h20v18c0 9-20 9-20 0Z" fill="#e9e1ca" />
          <path d="M11 0c14-2 14 14 0 12" fill="none" stroke="#e9e1ca" strokeWidth="5" />
          <path className="steam" d="M-3-9c-7-8 8-9 0-18" fill="none" stroke="#fff" strokeOpacity=".5" strokeWidth="2" />
        </g>
      )}
    </g>
  )
}

function Plant({ x, y }: { x: number; y: number }) {
  return (
    <g transform={`translate(${x} ${y})`}>
      <path d="m-20 0 20-10L20 0 0 11Z" fill="#a16c4f" />
      <path d="M-20 0 0 11v30L-20 30Z" fill="#7d4e3b" />
      <path d="M20 0 0 11v30l20-11Z" fill="#644035" />
      <path d="M0-4C-35-13-31-42 0-21 31-49 35-11 5-4 31-9 28 21 0 5-27 23-32-9 0-4Z" fill="#657d64" />
    </g>
  )
}

function OfficeScene() {
  return (
    <svg className="office-scene" viewBox="0 0 1000 650" role="img" aria-labelledby="office-title office-description">
      <title id="office-title">Escritório virtual do MyCockpit</title>
      <desc id="office-description">Três agentes em uma sala isométrica: Claude pensando, Codex escrevendo código e Antigravity disponível.</desc>
      <defs>
        <linearGradient id="leftWall" x1="0" x2="1" y1="0" y2="1">
          <stop stopColor="#bdc4b8" />
          <stop offset="1" stopColor="#a8b1a5" />
        </linearGradient>
        <linearGradient id="rightWall" x1="0" x2="1" y1="0" y2="1">
          <stop stopColor="#c8c9ba" />
          <stop offset="1" stopColor="#b4b8ac" />
        </linearGradient>
        <filter id="roomShadow" x="-30%" y="-30%" width="160%" height="180%">
          <feDropShadow dx="0" dy="25" stdDeviation="20" floodColor="#000" floodOpacity=".45" />
        </filter>
        <filter id="objectShadow" x="-50%" y="-50%" width="200%" height="220%">
          <feDropShadow dx="0" dy="8" stdDeviation="7" floodColor="#26302d" floodOpacity=".22" />
        </filter>
        <radialGradient id="lampGlow">
          <stop stopColor="#ffe79b" stopOpacity=".34" />
          <stop offset="1" stopColor="#ffe79b" stopOpacity="0" />
        </radialGradient>
      </defs>

      <g filter="url(#roomShadow)">
        <path d="M500 170 910 375 500 602 90 375Z" fill="#41504c" />
        <path d="M500 158 900 358 500 579 100 358Z" fill="#9cab8f" stroke="#667566" strokeWidth="3" />
        <path d="M100 358 500 158V38L100 238Z" fill="url(#leftWall)" stroke="#59645d" strokeWidth="3" />
        <path d="M500 158 900 358V238L500 38Z" fill="url(#rightWall)" stroke="#59645d" strokeWidth="3" />
        <path d="M100 238 500 38 900 238" fill="none" stroke="#33403d" strokeWidth="10" strokeLinejoin="round" />

        <g opacity=".28" stroke="#748470" strokeWidth="1">
          <path d="M180 318 580 518M260 278 660 478M340 238 740 438M420 198 820 398" />
          <path d="M820 318 420 518M740 278 340 478M660 238 260 438M580 198 180 398" />
        </g>
        <g opacity=".18" stroke="#738078">
          <path d="M225 175v120M350 113v120M650 113v120M775 175v120" />
        </g>
        <path d="M709 166v42l55 28v-42Z" fill="#313a3b" />
        <path d="M717 176v7l39 20v-7ZM717 190v7l39 20v-7" stroke="#87908a" strokeWidth="3" />
        <circle cx="500" cy="95" r="15" fill="#ece7d5" stroke="#59635f" strokeWidth="4" />
        <path d="M500 95V84m0 11 8 5" stroke="#444c49" strokeWidth="3" strokeLinecap="round" />

        <ellipse cx="510" cy="401" rx="190" ry="105" fill="url(#lampGlow)" />
        <g filter="url(#objectShadow)">
          <Desk x={310} y={325} />
          <Desk x={520} y={435} flip />
          <Desk x={700} y={316} />
          <Plant x={140} y={337} />
          <Plant x={836} y={394} />
        </g>

        <g filter="url(#objectShadow)">
          <AgentPiece agent={agents[0]} x={310} y={395} />
          <AgentPiece agent={agents[1]} x={520} y={382} />
          <AgentPiece agent={agents[2]} x={700} y={386} />
        </g>
      </g>
    </svg>
  )
}

function Mark() {
  return (
    <svg aria-hidden="true" viewBox="0 0 28 28">
      <path d="M14 2.5 17 11l8.5 3-8.5 3-3 8.5-3-8.5-8.5-3 8.5-3 3-8.5Z" />
    </svg>
  )
}

export default function App() {
  return (
    <main className="office-shell">
      <div className="noise" aria-hidden="true" />
      <header className="topbar">
        <div className="brand-lockup">
          <span className="brand-mark"><Mark /></span>
          <div><p className="eyebrow">MyCockpit</p><h1>Agent Office</h1></div>
        </div>
        <div className="project-chip" aria-label="Projeto ativo mycockpit">
          <span className="live-dot" /><span>mycockpit</span><span className="project-meta">M0 · simulação</span>
        </div>
      </header>

      <section className="scene-wrap" aria-label="Escritório virtual com três agentes">
        <OfficeScene />
        <div className="scene-caption"><span>Visão isométrica</span><span aria-hidden="true">·</span><span>3 agentes no escritório</span></div>
      </section>

      <aside className="status-panel" aria-label="Status dos agentes">
        <p className="panel-kicker">Equipe agora</p>
        <div className="agent-list">
          {agents.map((agent) => (
            <article className="agent-row" key={agent.id}>
              <span className="agent-beacon" style={{ '--beacon': stateColors[agent.state] } as React.CSSProperties} />
              <div className="agent-copy"><strong>{agent.name}</strong><span>{agent.role}</span></div>
              <div className="agent-state"><span>{stateCopy[agent.state]}</span><small>{agent.model}</small></div>
            </article>
          ))}
        </div>
        <p className="prototype-note">Estados simulados para validar o espaço antes da conexão ao runtime.</p>
      </aside>

      <footer className="instrument-strip">
        <span><i className="strip-light" /> Office online</span>
        <span>Render <b>SVG leve</b></span>
        <span>Fonte <b>AgentEvent</b></span>
        <span className="strip-time">Local only</span>
      </footer>
    </main>
  )
}
