export type AgentState = 'idle' | 'typing' | 'thinking'

export type Agent = {
  id: string
  name: string
  role: string
  model: string
  state: AgentState
  stateLabel: string
  color: string
  position: [number, number, number]
}

export const agents: Agent[] = [
  {
    id: 'claude',
    name: 'Claude',
    role: 'Arquitetura',
    model: 'Opus 4.1',
    state: 'thinking',
    stateLabel: 'Pensando',
    color: '#e4a862',
    position: [-2.8, 0, -1.45],
  },
  {
    id: 'codex',
    name: 'Codex',
    role: 'Implementação',
    model: 'GPT-5',
    state: 'typing',
    stateLabel: 'Escrevendo código',
    color: '#5bb8e8',
    position: [0.25, 0, 1.2],
  },
  {
    id: 'antigravity',
    name: 'Antigravity',
    role: 'Pesquisa',
    model: 'Gemini',
    state: 'idle',
    stateLabel: 'Disponível',
    color: '#5bd6a0',
    position: [3.1, 0, -1.25],
  },
]

export const stateColors: Record<AgentState, string> = {
  idle: '#5bd6a0',
  typing: '#5bb8e8',
  thinking: '#e4a862',
}
